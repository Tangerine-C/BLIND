DO NOT RUN THIS IN IDLE!
pycharm allows the carriage return \r to function properly.